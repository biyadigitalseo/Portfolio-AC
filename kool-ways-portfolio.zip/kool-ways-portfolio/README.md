# Afzal Hussain | KOOL Ways portfolio

Static site: `index.html`, `css/style.css`, `js/script.js`, `assets/images/`. All paths are relative.

## Publish on GitHub Pages
1. Create a repository and upload everything in this folder (keep the folder structure; `index.html` must be at the repository root).
2. Repository **Settings > Pages**: Source = *Deploy from a branch*, Branch = `main`, folder = `/ (root)`.
3. Open `https://<username>.github.io/<repository>/` after a minute or two.

## Editing
- Text and contact details: `index.html`
- Colours and fonts: variables at the top of `css/style.css`
- Photo: replace `assets/images/afzal-hussain.jpg` (keep the file name, or update the two `<img>` tags)
- Fonts load from Google Fonts; the page falls back to system fonts if offline.
